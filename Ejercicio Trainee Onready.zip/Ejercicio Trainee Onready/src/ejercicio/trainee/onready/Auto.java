
 
package ejercicio.trainee.onready;

import java.util.ArrayList;
import java.util.List;


public class Auto extends Vehiculo{
    
    protected int nroPuertas;

    public Auto() {
    }
    
    

    public Auto(int nroPuertas, String marca, String modelo, double precio) {
        super(marca, modelo, precio);
        this.nroPuertas = nroPuertas;
    }

    public void setNroPuertas(int nroPuertas) {
        this.nroPuertas = nroPuertas;
    }
    
    
    @Override
    public int getNroPuertas() {
        return nroPuertas;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }
    
    //Sobreescribimos el metodo original de la clase padre y cargamos los datos
    @Override
    public ArrayList cargarVehiculo(ArrayList Vehiculos){
    
     
        
    Auto auto1=new Auto(4,"Peugeot","206",200000.00); 
    Auto auto2=new Auto(5,"Peugeot","208",250000.00);
    
    Vehiculos.add(auto1);
    Vehiculos.add(auto2);
    
    return Vehiculos;
    }
    
}
