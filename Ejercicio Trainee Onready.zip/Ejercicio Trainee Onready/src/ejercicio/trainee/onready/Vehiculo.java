
package ejercicio.trainee.onready;

import java.util.ArrayList;
import java.util.Collections;


public class Vehiculo implements Comparable<Vehiculo>{
    
    protected String marca;
    protected String modelo;
    protected double precio;

    public Vehiculo() {
    }

    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }
    
     @Override
        public int compareTo(Vehiculo v) {
            if (precio > v.getPrecio()) {
                return -1;
            }
            if (precio < v.getPrecio()) {
                return 1;
            }
            return 0;
        }
    
    
    public ArrayList cargarVehiculo(ArrayList Vehiculos){ 
      
        
        return Vehiculos;}
    
 

    int getNroPuertas() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    String getCilindrada() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    
//Metodo que imprime el vehiculo de mayor y menor valor, además el modelo que contenga una letra en particular
    void detalles(ArrayList<Vehiculo> Vehiculos) {
        
        double precioMY=0;
        double precioMN=0;
        int MY=0;
        int MN=0;
        int letra=0;
        precioMY=Vehiculos.get(0).getPrecio();
        precioMN=Vehiculos.get(0).getPrecio();
        
        for(int i=1;i < Vehiculos.size(); i++){
            if(Vehiculos.get(i).getPrecio()>precioMY){
                precioMY=Vehiculos.get(i).getPrecio();
                MY=i;
        }
        }
          for(int j=1;j < Vehiculos.size(); j++){
            if(Vehiculos.get(j).getPrecio()<precioMN){
                precioMN=Vehiculos.get(j).getPrecio();
                MN=j;
        }
        
          }
          
          for(int x=0;x < Vehiculos.size(); x++){
              
              if(Vehiculos.get(x).getModelo().indexOf("Y")>-1){
                letra=x;
              
              }
          }
          
          
          
          System.out.println("=============================");
          
          System.out.println("Vehículo más caro: "+Vehiculos.get(MY).getMarca()+" "+Vehiculos.get(MY).getModelo());
          System.out.println("Vehículo más barato: "+Vehiculos.get(MN).getMarca()+" "+Vehiculos.get(MN).getModelo());
          System.out.println("Vehículo que contiene en el modelo la letra ‘Y’: "+Vehiculos.get(letra).getMarca()+" "+Vehiculos.get(letra).getModelo()+" "+Vehiculos.get(letra).getPrecio());
}

    
    //Ordena los vehiculos por su precio, utilice collections para el ordenamiento, sobreescribiendo su metodo
    // compareTo() para establecer el orden
    void Precios(ArrayList<Vehiculo> Vehiculos) {
        
        Collections.sort(Vehiculos);
        
        System.out.println("=============================");
        
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        
            for (int i = 0; i < Vehiculos.size(); i++) {
                System.out.println(Vehiculos.get(i).getMarca()+" "+Vehiculos.get(i).getModelo());
        }
   
    }

   
}
