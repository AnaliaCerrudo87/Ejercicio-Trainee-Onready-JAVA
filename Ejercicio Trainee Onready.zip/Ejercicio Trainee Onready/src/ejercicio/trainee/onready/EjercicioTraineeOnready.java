
package ejercicio.trainee.onready;

import java.util.ArrayList;


/**
 *
 * @author Analia
 */
public class EjercicioTraineeOnready {

  
    public static void main(String[] args) {
     
    ArrayList <Vehiculo> Vehiculos= new ArrayList <Vehiculo>();
          
        
        Auto nuevoA=new Auto();
        Moto nuevoB=new Moto();
        Vehiculo v=new Vehiculo();
        
        nuevoA.cargarVehiculo(Vehiculos);
        nuevoB.cargarVehiculo(Vehiculos);
        
    
     for (int i = 0; i < Vehiculos.size(); i++) {
        if(Vehiculos.get(i).getNroPuertas()>0){
            System.out.println("Marca:"+Vehiculos.get(i).getMarca()+" //"+" Modelo:"
             +Vehiculos.get(i).getModelo()+" // "+"Puertas:"+Vehiculos.get(i).getNroPuertas()+ " // "+"Precio:"+Vehiculos.get(i).getPrecio());}
     
        else{
            System.out.println("Marca:"+Vehiculos.get(i).getMarca()+" // "+"Modelo:"
             +Vehiculos.get(i).getModelo()+" // "+"Cilindrada:"+Vehiculos.get(i).getCilindrada()+ " // "+"Precio:"+Vehiculos.get(i).getPrecio());}
     }
     
           v.detalles(Vehiculos);
           v.Precios(Vehiculos);
    }
    }
    
    
    
    
    

