
package ejercicio.trainee.onready;

import java.util.ArrayList;


public class Moto extends Vehiculo {
    
    protected String cilindrada;

    public Moto() {
    }
    
    

    public Moto(String cilindrada, String marca, String modelo, double precio) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    public void setCilindrada(String cilindrada) {
        this.cilindrada = cilindrada;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String getCilindrada() {
        return cilindrada;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }
    
    public int getNroPuertas(){
    
        return 0;
    }
    
    //Sobreescribimos el metodo original de la clase padre y cargamos los datos
    @Override
    public ArrayList cargarVehiculo(ArrayList Vehiculos){
        
       
    
    Moto moto1=new Moto("125cc","Honda","Titan",60000.00);
    Moto moto2=new Moto("160cc","Yamaha","YBR",85000.50);
    
    Vehiculos.add(moto1);
    Vehiculos.add(moto2);
    
    return Vehiculos;
    
    }
    
}
